const express = require("express"); //importing necessary libraries
const mongoose = require("mongoose");
const csvtojson = require("csvtojson");
const bodyParser = require("body-parser");
//use dataset attchached to this file otherwise the program won't run properly
port = 3000;//setting port 
const app = express();//initialize express framework
const cors = require("cors");//using cors for setting http headers

app.use(bodyParser.json());//body parser to parse json object
app.use(bodyParser.urlencoded({ extended: false }));

app.use(cors());
const table = new mongoose.Schema({ //creating table schemas
  Policy_id: {
    type: String,
  },
  Date_of_Purchase: {
    type: Date,
  },
  Customer_id: {
    type: Number,
  },
  Fuel: {
    type: String,
  },
  VEHICLE_SEGMENT: {
    type: String,
  },
  Premium: {
    type: Number,
  },
  bodily_injury_liability: {
    type: Number,
  },
  personal_injury_protection: {
    type: Number,
  },
  property_damage_liability: {
    type: Number,
  },
  collision: {
    type: Number,
  },
  comprehensive: {
    type: Number,
  },
  Customer_Gender: {
    type: String,
  },
  Customer_Income_group: {
    type: String,
  },
  Customer_Region: {
    type: String,
  },
  Customer_Marital_status: {
    type: String,
  },
});

const Customer = mongoose.model("Customer", table);//creating our customer model

mongoose.connect( //connecting to database
  "mongodb://localhost/insurance",
  (err) => {
    if (err) throw err;
    console.log("Successfully connected");
  },
  { useNewUrlParser: true, useUnifiedTopology: true }
);
//importing our csv file to mongodb database
csvtojson() //please use dataset attached to this file i have made few changes to it like removing spacing
  .fromFile("/home/admi/Downloads/Data Set - Insurance Client.csv")
  .then((data) => {
    data.forEach((ele) => {
      let savedata = new Customer(ele);
      savedata.save((err) => {
        if (err) throw err;
      });
    });
  })
  .catch((err) => console.log(err));

app.get("/api", async (req, res) => { //setting up routes
  const count = await Customer.find({});
  res.send(count);
});
app.get("/:id", async (req, res) => {
  const customer = await Customer.find({ Policy_id: req.params.id });
  res.send(customer);
});

app.get("/", async (req, res) => {
  try {
    await Customer.aggregate(
      [
        {
          $group: { _id: { $month: "$Date_of_Purchase" }, count: { $sum: 1 } },
        },
      ],
      function (err, data) {
        if (err) {
          res.json(500);
        } else {
          res.json({ data });
        }
      }
    );
  } catch (ex) {
    console.log(ex);
  }
});

app.post("/", async (req, res) => {
  let customer = new Customer({
    Policy_id: req.body.policy_id,
    Date_of_Purchase: req.body.date_of_purchase,
    Customer_id: req.body.customer_id,
    Fuel: req.body.fuel,
    Vehicle_Segment: req.body.vehicle_segment,
    Premium: req.body.premium,
    Body_injury_liablity: req.body.body_injury_liablity,
    Personal_injury_protection: req.body.personal_injury_protection,
    Property_damage_liablity: req.body.property_damage_liablity,
    collision: req.body.collision,
    comprehensive: req.body.comprehensive,
    Customer_gender: req.body.customer_gender,
    Customer_income_group: req.body.customer_income_group,
    Customer_region: req.body.customer_region,
    Customer_marital_status: req.body.customer_marital_status,
  });
  customer = await customer.save();
  res.send(customer);
});

app.delete("/:id", async (req, res) => {
  let customer = await Customer.findByIdAndRemove(req.params.id);
  if (!customer) {
    res.status(404).send("Customer with given id not found");
  }
  res.send(customer);
});

app.patch("/:id", async (req, res) => {
  let customer = await Customer.findByIdAndUpdate(
    req.params.id,
    {
      Policy_id: req.body.policy_id,
      Date_of_Purchase: req.body.date_of_purchase,
      Customer_id: req.body.customer_id,
      Fuel: req.body.fuel,
      Vehicle_Segment: req.body.vehicle_segment,
      Premium: req.body.premium,
      Body_injury_liablity: req.body.body_injury_liablity,
      Personal_injury_protection: req.body.personal_injury_protection,
      Property_damage_liablity: req.body.property_damage_liablity,
      collision: req.body.collision,
      comprehensive: req.body.comprehensive,
      Customer_gender: req.body.customer_gender,
      Customer_income_group: req.body.customer_income_group,
      Customer_region: req.body.customer_region,
      Customer_marital_status: req.body.customer_marital_status,
    },
    { new: false }
  );
  if (!customer) {
    res.status(404).send("Customer with given id not found");
  }
  res.send(customer);
});

app.listen(port, () => {//listening on local host
  console.log(`Listening on port ${port}`);
});
