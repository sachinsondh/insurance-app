const express = require("express");
const mongoose = require("mongoose");
const csvtojson = require("csvtojson");
const bodyParser = require("body-parser");

port = 3000;
const app = express();
const cors = require("cors");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(cors());
const table = new mongoose.Schema({
  Policy_id: {
    type: String,
  },
  Date_of_Purchase: {
    type: Date,
  },
  Customer_id: {
    type: Number,
  },
  Fuel: {
    type: String,
  },
  Vehicle_segment: {
    type: String,
  },
  Premium: {
    type: Number,
  },
  bodily_injury_liability: {
    type: Number,
  },
  personal_injury_protection: {
    type: Number,
  },
  property_damage_liability: {
    type: Number,
  },
  collision: {
    type: Number,
  },
  comprehensive: {
    type: Number,
  },
  Customer_Gender: {
    type: String,
  },
  Customer_Income_group: {
    type: String,
  },
  Customer_Region: {
    type: String,
  },
  Customer_Marital_status: {
    type: String,
  },
});

const Customer = mongoose.model("Customer", table);

mongoose.connect(
  "mongodb://localhost/insurance",
  (err) => {
    if (err) throw err;
    console.log("Successfully connected");
  },
  { useNewUrlParser: true, useUnifiedTopology: true }
);

csvtojson()
  .fromFile(
    "/home/sachin/Documents/case_study-Sachin_Sondh/Data Set - Insurance Client.csv"
  )
  .then((data) => {
    data.forEach((ele) => {
      let savedata = new Customer(ele);
      savedata.save((err) => {
        if (err) throw err;
      });
    });
  })
  .catch((err) => console.log(err));

app.get("/api", async (req, res) => {
  const count = await Customer.find({});
  res.send(count);
});
app.get("/:id", async (req, res) => {
  const customer = await Customer.find({ Policy_id: req.params.id });
  res.send(customer);
});

app.get("/api/1", async (req, res) => {
  try {
    await Customer.aggregate(
      [
        { $match: { Customer_Region: "North" } },
        {
          $group: { _id: { $month: "$Date_of_Purchase" }, count: { $sum: 1 } },
        },
      ],
      function (err, data) {
        if (err) {
          res.json(500);
        } else {
          res.json({ data });
        }
      }
    );
  } catch (ex) {
    console.log(ex);
  }
});

app.get("/api/2", async (req, res) => {
  try {
    await Customer.aggregate(
      [
        { $match: { Customer_Region: "South" } },
        {
          $group: { _id: { $month: "$Date_of_Purchase" }, count: { $sum: 1 } },
        },
      ],
      function (err, data) {
        if (err) {
          res.json(500);
        } else {
          res.json({ data });
        }
      }
    );
  } catch (ex) {
    console.log(ex);
  }
});

app.get("/api/3", async (req, res) => {
  try {
    await Customer.aggregate(
      [
        { $match: { Customer_Region: "East" } },
        {
          $group: { _id: { $month: "$Date_of_Purchase" }, count: { $sum: 1 } },
        },
      ],
      function (err, data) {
        if (err) {
          res.json(500);
        } else {
          res.json({ data });
        }
      }
    );
  } catch (ex) {
    console.log(ex);
  }
});

app.get("/api/4", async (req, res) => {
  try {
    await Customer.aggregate(
      [
        { $match: { Customer_Region: "West" } },
        {
          $group: { _id: { $month: "$Date_of_Purchase" }, count: { $sum: 1 } },
        },
      ],
      function (err, data) {
        if (err) {
          res.json(500);
        } else {
          res.json({ data });
        }
      }
    );
  } catch (ex) {
    console.log(ex);
  }
});

app.post("/", async (req, res) => {
  let customer = new Customer({
    Policy_id: req.body.policy_id,
    Date_of_Purchase: req.body.date_of_purchase,
    Customer_id: req.body.customer_id,
    Fuel: req.body.fuel,
    Vehicle_Segment: req.body.vehicle_segment,
    Premium: req.body.premium,
    Body_injury_liablity: req.body.body_injury_liablity,
    Personal_injury_protection: req.body.personal_injury_protection,
    Property_damage_liablity: req.body.property_damage_liablity,
    collision: req.body.collision,
    comprehensive: req.body.comprehensive,
    Customer_gender: req.body.customer_gender,
    Customer_income_group: req.body.customer_income_group,
    Customer_region: req.body.customer_region,
    Customer_marital_status: req.body.customer_marital_status,
  });
  customer = await customer.save();
  res.send(customer);
});

app.delete("/:id", async (req, res) => {
  let customer = await Customer.findByIdAndRemove(req.params.id);
  if (!customer) {
    res.status(404).send("Customer with given id not found");
  }
  res.send(customer);
});

app.patch("/:id", async (req, res) => {
  let customer = await Customer.findByIdAndUpdate(
    req.params.id,
    {
      Policy_id: req.body.policy_id,
      Date_of_Purchase: req.body.date_of_purchase,
      Customer_id: req.body.customer_id,
      Fuel: req.body.fuel,
      Vehicle_Segment: req.body.vehicle_segment,
      Premium: req.body.premium,
      Body_injury_liablity: req.body.body_injury_liablity,
      Personal_injury_protection: req.body.personal_injury_protection,
      Property_damage_liablity: req.body.property_damage_liablity,
      collision: req.body.collision,
      comprehensive: req.body.comprehensive,
      Customer_gender: req.body.customer_gender,
      Customer_income_group: req.body.customer_income_group,
      Customer_region: req.body.customer_region,
      Customer_marital_status: req.body.customer_marital_status,
    },
    { new: false }
  );
  if (!customer) {
    res.status(404).send("Customer with given id not found");
  }
  res.send(customer);
});

app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});
