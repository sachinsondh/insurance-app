import React, { Component } from "react";

import axios from "axios";
import Display from "./barchart";

class Chart extends Component {
  state = {
    North: [],
    South: [],
    East: [],
    West: [], //setting up chart component & getting data from server
  };
  async componentDidMount() {
    await axios
      .get("http://localhost:3000/api/1")
      .then((res) => {
        this.setState({ North: res.data.data });
        console.log(this.state.North);
      })
      .catch((err) => console.log(`Server Error: ${err}`));

    await axios
      .get("http://localhost:3000/api/2")
      .then((res) => {
        this.setState({ South: res.data.data });
        console.log(this.state.South);
      })
      .catch((err) => console.log(`Server Error: ${err}`));

    await axios
      .get("http://localhost:3000/api/3")
      .then((res) => {
        this.setState({ East: res.data.data });
        console.log(this.state.East);
      })
      .catch((err) => console.log(`Server Error: ${err}`));

    await axios
      .get("http://localhost:3000/api/4")
      .then((res) => {
        this.setState({ West: res.data.data });
        console.log(this.state.West);
      })
      .catch((err) => console.log(`Server Error: ${err}`));
  }
  render() {
    return (
      <div>
        <h2>Policy Sale each month for north region </h2>
        <Display data={this.state.North} />
        <h2>Policy Sale each month for south region </h2>
        <Display data={this.state.South} />
        <h2>Policy Sale each month for east region</h2>
        <Display data={this.state.East} />
        <h2>Policy Sale each month for west region</h2>
        <Display data={this.state.West} />
      </div>
    );
  }
}

export default Chart;
