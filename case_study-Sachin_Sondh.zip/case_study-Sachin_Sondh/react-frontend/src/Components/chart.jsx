import React, { Component } from "react";

import axios from "axios";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

class Chart extends Component {
  state = {
    data: [], //setting up chart component & getting data from server
  };
  async componentDidMount() {
    await axios
      .get("http://localhost:3000/")
      .then((res) => {
        this.setState({ data: res.data.data });
        console.log(this.state.data);
      })
      .catch((err) => console.log(`Server Error: ${err}`));
  }
  render() {
    return (
      <div>
        <h2>Policy Sale each month </h2>
        <BarChart
          width={500}
          height={300}
          data={this.state.data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="name"
            label="Months"
            rotate="30"
            ticks={[
              "Jan",
              "Feb",
              "Mar",
              "Apr",
              "May",
              "June",
              "July",
              "Aug",
              "Sept",
              "Oct",
              "Nov",
              "Dec",
            ]}
          />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="count" fill="#8884d8" />
        </BarChart>
      </div>
    );
  }
}

export default Chart;
