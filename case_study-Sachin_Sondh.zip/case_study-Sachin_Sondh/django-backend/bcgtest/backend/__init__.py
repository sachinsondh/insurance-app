# import os
# import csv
# import io
# import json
# import sys

# from pymongo import MongoClient
# from backend.models import Policy
# import django


# mongo_client = MongoClient()
# db = mongo_client.policies


# csv_file = open('/home/sachin/Documents/Data Set - Insurance Client.csv', 'r')


# # data_set = csv_file.read().decode('UTF-8')
# # io_string = io.StringIO(csv_file)
# # next(io_string)
# db.segment.drop()

# for column in csv.reader(csv_file, delimiter=',', quotechar="|"):
#     _, created = Policy.objects.update_or_create(
#         Policy_id=column[0],
#         Date_of_Purchase=column[1],
#         Customer_id=column[2],
#         Fuel=column[3],
#         Vehicle_Segment=column[4],
#         Premium=column[5],
#         bodily_injury_liability=column[6],
#         personal_injury_protection=column[7],
#         property_damage_liablity=column[8],
#         collision=column[9],
#         comprehensive=column[10],
#         Customer_Gender=column[11],
#         Customer_Income_group=column[12],
#         Customer_Region=column[13],
#         Customer_Marital_status=column[14]
#     )
#     db.segment.insert(created)
