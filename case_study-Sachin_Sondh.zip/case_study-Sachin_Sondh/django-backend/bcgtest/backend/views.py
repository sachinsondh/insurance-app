from django.shortcuts import render
from backend.models import Policy
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from bson.objectid import ObjectId
# Create your views here.


@csrf_exempt
def add_policy(request):
    policy = Policy(Policy_id=request.POST.get("Policy_id"),

                    Date_of_Purchase=request.POST.get("Date_of_Purchase"),
                    Customer_id=request.POST.get("Customer_id"),
                    Fuel=request.POST.get("Fuel"),
                    Vehicle_Segment=request.POST.get("Vehicle_Segment"),
                    Premium=request.POST.get("Premium "),
                    bodily_injury_liability=request.POST.get(
                        "bodily_injury_liability"),
                    personal_injury_protection=request.POST.get(
                        "personal_injury_protection"),
                    property_damage_liablity=request.POST.get(
                        "property_damage_liablity"),
                    collision=request.POST.get("collision"),
                    comprehensive=request.POST.get("comprehensive"),
                    Customer_Gender=request.POST.get("Customer_Gender"),
                    Customer_Income_group=request.POST.get(
                        "Customer_Income_group"),
                    Customer_Region=request.POST.get("Customer_Region"),

                    Customer_Marital_status=request.POST.get(
                        "Customer_Marital_status")

                    )
    policy.save()
    return HttpResponse("Inserted")


def update_policy(request, id):
    pass


def delete_policy(request, id):
    pass


def get_policy(request):
    policy = Policy.objects.all()
    return HttpResponse(policy)


def read_policy(request, id):
    policy = Policy.objects.get(id=ObjectId(id))
    return HttpResponse(policy)
