from djongo import models

# Create your models here.


class Policy(models.Model):
    id = models.ObjectIdField()
    Policy_id = models.IntegerField()
    Date_of_Purchase = models.DateField()
    Customer_id = models.IntegerField()
    Fuel = models.CharField(max_length=30)
    Vehicle_Segment = models.CharField(max_length=30)
    Premium = models.IntegerField()
    bodily_injury_liability = models.IntegerField()
    personal_injury_protection = models.IntegerField()
    property_damage_liablity = models.IntegerField()
    collision = models.IntegerField()
    comprehensive = models.IntegerField()
    Customer_Gender = models.TextField()
    Customer_Income_group = models.CharField(max_length=30)
    Customer_Region = models.TextField()
    Customer_Marital_status = models.IntegerField()
    objects = models.DjongoManager()
